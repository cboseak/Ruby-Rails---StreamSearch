            var gbkey = "rKiM2zR4cTaMZM3VLtkqjaG7NmQssvh7";
            var gbbase = "https://api-public.guidebox.com/v1.43/US/";
            var dbkey = "07d7a1ec56ce1670ec201f585a6d5fda";
            var amzLogo = "https://s3.amazonaws.com/BURC_Pages/downloads/a-smile_color.png";
            var itunesLogo = "http://www.wretchesandjabberers.org/images/ITunes10_Logo.png";
            var huluLogo = "http://cdn.embed.ly/providers/logos/hulu.png";
            var vuduLogo = "http://findicons.com/files/icons/2145/private_stock/128/ps_vudu_logo.png";
            var gpLogo = "http://www.solitaireforever.com/logo_google_play.png";
            var cinemaNowLogo = "https://www.oppodigital.com/blu-ray-bdp-103/images/cinemanow-logo.png";
            var youtubeLogo = "https://cdn3.iconfinder.com/data/icons/ultimate-social/150/38_youtube_a-128.png";
            var sonyLogo = "http://www.myiconfinder.com/uploads/iconsets/128-128-0cdab4780cac80f750cef0f3423aa7c3-sony.png";
            var flixsterLogo = "http://www.thechromesource.com/wp-content/uploads/2011/05/Logo.png";
            var crackleLogo = "http://sanec.com.br/busca/img/crackle.png";
            var xboxLogo = "http://www.xbox.com/shell/images/shell/XboxLogo.png";
            var mgoLogo = "http://www.ultravioletcinema.com/images/primer/mgoLogo_120x80.png";
            var netflixLogo = "http://icons.iconarchive.com/icons/chrisbanks2/cold-fusion-hd/128/netflix-icon.png";
            
